(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text("2016", "bold 10px 'Muli'");
	this.text.lineHeight = 15;
	this.text.parent = this;
	this.text.setTransform(2,2.7);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.7,28.2,16.6);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text("050 048 049 054", "10px 'Muli Light'", "#6FDC95");
	this.text.lineHeight = 15;
	this.text.parent = this;
	this.text.setTransform(2,2.7);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.7,83.9,16.6);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape.setTransform(53.875,3.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_1.setTransform(31.875,3.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_2.setTransform(56.275,3.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_3.setTransform(34.275,3.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6FDC95").s().p("AgcAjIAphFIAQAAIgqBFg");
	this.shape_4.setTransform(58.7,3.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6FDC95").s().p("AgcAjIAphFIAPAAIgpBFg");
	this.shape_5.setTransform(36.7,3.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_6.setTransform(61.125,3.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_7.setTransform(39.125,3.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_8.setTransform(41.55,3.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_9.setTransform(2.825,3.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#6FDC95").s().p("AgbAjIAohFIAQAAIgqBFg");
	this.shape_10.setTransform(5.25,3.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#6FDC95").s().p("AgcAjIAphFIAQAAIgqBFg");
	this.shape_11.setTransform(7.65,3.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_12.setTransform(10.075,3.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#6FDC95").s().p("AgcAjIAphFIAPAAIgpBFg");
	this.shape_13.setTransform(12.5,3.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_14.setTransform(14.925,3.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_15.setTransform(17.35,3.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_16.setTransform(19.75,3.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#6FDC95").s().p("AgcAjIAphFIAQAAIgqBFg");
	this.shape_17.setTransform(44.2,3.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_18.setTransform(22.2,3.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_19.setTransform(46.6,3.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#6FDC95").s().p("AgbAjIAohFIAQAAIgqBFg");
	this.shape_20.setTransform(24.6,3.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_21.setTransform(49.025,3.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_22.setTransform(27.025,3.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#6FDC95").s().p("AgbAjIAohFIAPAAIgpBFg");
	this.shape_23.setTransform(51.45,3.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#6FDC95").s().p("AgcAjIAphFIAQAAIgqBFg");
	this.shape_24.setTransform(29.45,3.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,64,7);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6FDC95").s().p("AlxAPIAAgdILjAAIAAAdg");
	this.shape.setTransform(56.2344,1.5964,1.5203,1,0,0,-0.1018);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,112.5,3.2);


// stage content:
(lib.DATE = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Symbol9("synched",0);
	this.instance.setTransform(115.95,4.25,1,1,0,0,0,14.1,8.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(5));

	// Layer_1
	this.instance_1 = new lib.Symbol8("synched",0);
	this.instance_1.setTransform(59.9,4.25,1,1,0,0,0,41.9,8.2);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:1},8).to({startPosition:0},1).wait(5));

	// Layer_1
	this.instance_2 = new lib.Symbol7("synched",0);
	this.instance_2.setTransform(49.6,12.5,1,1,0,0,0,31.9,3.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:97.85},8).wait(6));

	// Layer_1
	this.instance_3 = new lib.Symbol6("synched",0);
	this.instance_3.setTransform(129,12.6,0.0178,1,0,0,0,56.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:1,x:73.7},4).wait(10));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(82.5,4.8,47.599999999999994,11.2);
// library properties:
lib.properties = {
	id: '67D7CAC628F84AD894D58C8B414E8F7E',
	width: 130,
	height: 16,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['67D7CAC628F84AD894D58C8B414E8F7E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;